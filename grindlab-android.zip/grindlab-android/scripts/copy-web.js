// Copie les fichiers web de l'app dans www/ (dossier lu par Capacitor).
const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");
const out = path.join(root, "www");
const files = ["index.html", "app.js", "logic.js", "styles.css", "manifest.webmanifest", "sw.js"];

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
for (const f of files) fs.copyFileSync(path.join(root, f), path.join(out, f));
fs.cpSync(path.join(root, "icons"), path.join(out, "icons"), { recursive: true });
console.log("www/ prêt :", fs.readdirSync(out).join(", "));
