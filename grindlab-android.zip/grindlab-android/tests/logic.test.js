const assert = require("assert");
const GL = require("../logic.js");

const nat = GL.nationalBands();
assert.strictEqual(GL.bandFor(1700, nat), "Modestes");
assert.strictEqual(GL.bandFor(1700, GL.STUDENT), "Aisés");

let nb = GL.nextBand(1700, nat);
assert.strictEqual(nb.name, "Médians");
assert.strictEqual(Math.round(nb.gap), 125);
nb = GL.nextBand(1700, GL.STUDENT);
assert.strictEqual(nb.name, "Très aisés");
assert.strictEqual(nb.gap, 300);
assert.strictEqual(GL.nextBand(5000, GL.STUDENT), null);

const b = GL.budget(GL.DEFAULT_PROFILE);
assert.strictEqual(b.rav, 1025);
assert.strictEqual(Math.round(b.effort * 100), 40);

const s = { gross: 300, hours: 0, netRatio: 0.85, aidLoss: 0.25 };
assert(Math.abs(GL.netGain(s) - 191.25) < 1e-9);
assert(GL.combine(1700, [s]).newIncome > 1700);
assert.strictEqual(GL.combine(1700, [{ gross: 100, hours: 50, netRatio: 0.8, aidLoss: 0.2 }]).overload, true);

let rows = GL.project(100, 10, 0);
assert.strictEqual(Math.round(rows[rows.length - 1].nominal), 12000);
rows = GL.project(100, 10, 0.05, 0, 0.02);
assert(rows[rows.length - 1].real < rows[rows.length - 1].nominal);
assert.strictEqual(GL.monthsToTarget(1200, 100, 0), 12);
assert.strictEqual(GL.monthsToTarget(1e9, 10, 0, 0, 0, 1), null);

for (const style of GL.STYLES) {
  for (const budget of [0, 100, 400, 1500, 6000]) {
    const plan = GL.planWardrobe(GL.CATALOG, style, budget);
    assert(plan.spent <= budget + 1e-9, style + " " + budget);
    const sum = plan.rows.reduce((a, r) => a + r.price, 0);
    assert(Math.abs(sum - plan.spent) < 1e-6);
  }
}

const csv = "Date;Libellé;Débit;Crédit\n02/09/2026;CARREFOUR CITY;45,20;\n03/09/2026;LOYER SEPTEMBRE;675,00;\n05/09/2026;VIREMENT SALAIRE;;1 450,00\n07/09/2026;ZARA;39,99;\n";
const r = GL.importBank(csv);
assert.strictEqual(r.count, 4);
assert.strictEqual(Math.round(r.avg.logement), 675);
assert(r.avg.courses > 45 && r.avg.vetements > 39);
assert(!("revenus" in r.avg));
assert.throws(() => GL.importBank("a;b\n1;2\n"));

console.log("logic.js : tous les tests passent");
